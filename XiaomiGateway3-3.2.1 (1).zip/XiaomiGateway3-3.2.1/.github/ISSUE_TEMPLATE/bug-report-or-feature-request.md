---
name: Bug report or Feature request
about: Default issue
title: ''
labels: ''
assignees: ''

---

<!--
- Write issue ONLY in English
- Search if similar issue already exist, also check closed issues, do not create duplicates
- Check Integration errors in Hass logs (Configuration > Logs), maybe answer there
- Check Integration debug (Configuration > Integrations > Xiaomi Gateway 3 > Configure > Debug) for something useful
- Read the readme carefully, maybe the answer is there
- Check if you using supported gateway firmware
-->
